using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class RuntimeKeyboardBuilder : MonoBehaviour
{
    [Header("Targets")]
    public Canvas parentCanvas;               // ������̹��ڴ� Canvas ��
    public InputField targetInput;            // ��ѡ���Զ��󶨵��� InputField����ͨ�� ShowFor ָ����

    [Header("Layout / Style")]
    public Vector2 keySize = new Vector2(64, 64);
    public int fontSize = 24;
    public Vector2 panelPadding = new Vector2(8, 8);
    public float rowSpacing = 6f;
    public float keySpacing = 6f;
    public Color keyColor = new Color(0.9f, 0.9f, 0.9f, 1f);
    public Color keyTextColor = Color.black;

    [Header("Behavior")]
    public bool autoAttachToTarget = true;    // �Զ�Ϊ targetInput ���ӵ��/ѡ�е���
    public bool hideOnSubmit = true;

    private GameObject keyboardRoot;
    private InputField currentInput;
    private Font defaultFont;

    private readonly string[] rows = new[]
    {
        "1234567890",
        "QWERTYUIOP",
        "ASDFGHJKL",
        "ZXCVBNM"
    };

    private void Awake()
    {
        defaultFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
    }

    private void Start()
    {
        if (parentCanvas == null)
        {
            Debug.LogWarning("RuntimeKeyboardBuilder: ���� Inspector ָ�� parentCanvas��Canvas����");
            return;
        }

        if (autoAttachToTarget && targetInput != null)
            AttachInputTriggers(targetInput);
    }

    // ��ָ�� InputField ����ʾ���̲���
    public void ShowFor(InputField input)
    {
        if (parentCanvas == null)
            return;

        currentInput = input ?? targetInput;

        if (keyboardRoot == null)
            BuildKeyboard();

        keyboardRoot.SetActive(true);

        // ���� EventSystem ѡ������ʾ caret
        EventSystem.current?.SetSelectedGameObject(currentInput?.gameObject);
    }

    public void Hide()
    {
        if (keyboardRoot != null) keyboardRoot.SetActive(false);
        currentInput = null;
        EventSystem.current?.SetSelectedGameObject(null);
    }

    // ����ʱ��������
    public void BuildKeyboard()
    {
        if (parentCanvas == null)
            throw new InvalidOperationException("parentCanvas δ���á�");

        if (keyboardRoot != null)
        {
            Destroy(keyboardRoot);
            keyboardRoot = null;
        }

        // Root panel
        keyboardRoot = new GameObject("VirtualKeyboardPanel", typeof(RectTransform));
        keyboardRoot.transform.SetParent(parentCanvas.transform, false);
        var rootRt = keyboardRoot.GetComponent<RectTransform>();
        rootRt.anchorMin = new Vector2(0.5f, 0f);
        rootRt.anchorMax = new Vector2(0.5f, 0f);
        rootRt.pivot = new Vector2(0.5f, 0f);
        rootRt.sizeDelta = new Vector2(parentCanvas.GetComponent<RectTransform>().rect.width - 40f, (keySize.y + rowSpacing) * (rows.Length + 2) + panelPadding.y * 2);
        rootRt.anchoredPosition = new Vector2(0f, 10f);

        var bg = keyboardRoot.AddComponent<Image>();
        bg.color = new Color(0.12f, 0.12f, 0.12f, 0.95f);

        // Vertical container for rows
        var vertical = keyboardRoot.AddComponent<VerticalLayoutGroup>();
        vertical.spacing = rowSpacing;
        vertical.padding = new RectOffset((int)panelPadding.x, (int)panelPadding.x, (int)panelPadding.y, (int)panelPadding.y);
        vertical.childAlignment = TextAnchor.MiddleCenter;
        vertical.childControlHeight = false;
        vertical.childControlWidth = false;

        // Create rows of keys
        foreach (var row in rows)
        {
            CreateKeyRow(keyboardRoot.transform, row);
        }

        // Bottom row: space + backspace + enter + close
        CreateBottomRow(keyboardRoot.transform);

        // ��ʼ���أ����� ShowFor ��ʾ��
        keyboardRoot.SetActive(false);
    }

    private void CreateKeyRow(Transform parent, string keys)
    {
        var row = new GameObject("Row", typeof(RectTransform));
        row.transform.SetParent(parent, false);
        var rowRt = row.GetComponent<RectTransform>();
        rowRt.sizeDelta = new Vector2(0, keySize.y);

        var layout = row.AddComponent<HorizontalLayoutGroup>();
        layout.spacing = keySpacing;
        layout.childAlignment = TextAnchor.MiddleCenter;
        layout.childControlHeight = false;
        layout.childControlWidth = false;

        // Create each key
        foreach (char c in keys)
        {
            CreateKey(c.ToString(), row.transform, () => OnKeyPressed(c.ToString()));
        }
    }

    private void CreateBottomRow(Transform parent)
    {
        var row = new GameObject("BottomRow", typeof(RectTransform));
        row.transform.SetParent(parent, false);
        var rowRt = row.GetComponent<RectTransform>();
        rowRt.sizeDelta = new Vector2(0, keySize.y);

        var layout = row.AddComponent<HorizontalLayoutGroup>();
        layout.spacing = keySpacing;
        layout.childAlignment = TextAnchor.MiddleCenter;
        layout.childControlHeight = false;
        layout.childControlWidth = false;

        // Space (larger)
        CreateKey("Space", row.transform, () => OnKeyPressed(" "), keyWidthMultiplier: 4f);

        // Backspace
        CreateKey("��", row.transform, Backspace);

        // Enter
        CreateKey("Enter", row.transform, Enter);

        // Close
        CreateKey("Close", row.transform, Hide);
    }

    private void CreateKey(string label, Transform parent, UnityAction action, float keyWidthMultiplier = 1f)
    {
        var go = new GameObject("Key_" + label, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(keySize.x * keyWidthMultiplier, keySize.y);

        var img = go.AddComponent<Image>();
        img.color = keyColor;

        var btn = go.AddComponent<Button>();
        btn.targetGraphic = img;
        btn.onClick.AddListener(action);

        // Text child
        var txtGo = new GameObject("Text", typeof(RectTransform));
        txtGo.transform.SetParent(go.transform, false);
        var txtRt = txtGo.GetComponent<RectTransform>();
        txtRt.anchorMin = Vector2.zero;
        txtRt.anchorMax = Vector2.one;
        txtRt.offsetMin = Vector2.zero;
        txtRt.offsetMax = Vector2.zero;

        var text = txtGo.AddComponent<Text>();
        text.text = label;
        text.alignment = TextAnchor.MiddleCenter;
        text.color = keyTextColor;
        text.font = defaultFont;
        text.fontSize = fontSize;
    }

    private void OnKeyPressed(string s)
    {
        if (currentInput == null)
        {
            Debug.LogWarning("VirtualKeyboard: ��ǰû�а󶨵� InputField������ ShowFor(InputField) �԰󶨡�");
            return;
        }

        int pos = currentInput.caretPosition;
        string text = currentInput.text ?? string.Empty;
        text = text.Insert(pos, s);
        currentInput.text = text;
        currentInput.caretPosition = pos + s.Length;
    }

    private void Backspace()
    {
        if (currentInput == null) return;
        int pos = currentInput.caretPosition;
        if (pos <= 0) return;
        string text = currentInput.text ?? string.Empty;
        text = text.Remove(pos - 1, 1);
        currentInput.text = text;
        currentInput.caretPosition = pos - 1;
    }

    private void Enter()
    {
        if (currentInput == null) return;
        currentInput.onEndEdit?.Invoke(currentInput.text);
        if (hideOnSubmit) Hide();
    }

    // �Զ�Ϊ InputField ���� EventTrigger�������ѡ��ʱ ShowFor
    private void AttachInputTriggers(InputField input)
    {
        if (input == null) return;

        var trigger = input.gameObject.GetComponent<EventTrigger>() ?? input.gameObject.AddComponent<EventTrigger>();

        AddTriggerEvent(trigger, EventTriggerType.PointerClick, (data) => { ShowFor(input); });
        AddTriggerEvent(trigger, EventTriggerType.Select, (data) => { ShowFor(input); });
    }

    private void AddTriggerEvent(EventTrigger trigger, EventTriggerType type, UnityAction<BaseEventData> callback)
    {
        var entry = new EventTrigger.Entry { eventID = type };
        entry.callback.AddListener(new UnityAction<BaseEventData>(callback));
        trigger.triggers.Add(entry);
    }
}